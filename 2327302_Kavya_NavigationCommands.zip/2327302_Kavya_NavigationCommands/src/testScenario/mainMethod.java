package testScenario;
import java.util.Scanner;
import org.openqa.selenium.*;
import testObjectRepository.Navigation_Commands;
import userDefinedLibraries.DriverSetup;
import userDefinedLibraries.Screenshot;

public class mainMethod {
	public static WebDriver driver;
	public static void main(String[] args) throws InterruptedException{
		String browser="";
		System.out.println("Enter the browser name : Chrome or Edge");
		Scanner sc = new Scanner(System.in);
		browser=sc.nextLine();
		sc.close();
		driverconfig(browser);
	
		Navigation_Commands ncp=new Navigation_Commands(driver);
		ncp.search("Orange HRM demo");
		ncp.navigateBack();
		ncp.navigateForward();
		ncp.navigateTo();
		ncp.ContactSalesbutton();
		ncp.setFullName("Vikram Rathode");
		ncp.setPhoneNumber("1234567890");
		ncp.setEmail("rathodeitsolutions.test@test.com");
		ncp.Country("India");
        ncp.Employee("11 - 15");
        ncp.setJobTitle("Fresher");
        ncp.scrolling();
        ncp.clickCaptcha();
        ncp.clickSubmit();  
        Screenshot.screenShotOfResultPage(driver,"page");
        ncp.setMessage("Hello");
        ncp.scrolling();
        ncp.clickCaptcha();
        ncp.clickSubmit();
        ncp.tearDown();
        System.out.println("Test completed successfully");
	}


	public static void driverconfig(String browser) {
		driver=DriverSetup.driverInstantiate(browser);	
	}

	

}


