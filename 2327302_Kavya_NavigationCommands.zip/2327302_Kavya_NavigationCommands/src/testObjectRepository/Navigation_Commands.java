package testObjectRepository;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.WebElement;

	    public class Navigation_Commands
	    {
		public WebDriver driver;
		// Constructor to initialize the WebDriver
		public Navigation_Commands(WebDriver driver){
			this.driver=driver;	
		}
		
		// Perform a search action
		public void search(String text) {
			WebElement searchBox = driver.findElement(By.id("APjFqb"));
	        searchBox.sendKeys(text);
	        searchBox.sendKeys(Keys.ENTER);
		}
		// Navigate back in the browser history
		public void navigateBack() {
			driver.navigate().back(); 
			String act_title=driver.getTitle();
			String exp_title="Google";
			if(act_title.equals(exp_title)) {
				System.out.println("Navigated back successfully");
			}
			else {
				System.out.println("Navigated back not successfull");
			}
			
		}
		// Navigate forward in the browser history
		public void navigateForward() {
			driver.navigate().forward();
			String act=driver.getTitle();
			String exp="Orange HRM demo - Google Search";
			if(act.equals(exp)) {
				System.out.println("Navigated forward successfully");
			}
			else {
				System.out.println("Navigated forward not successfull");
			}
		}
		// Navigate to a specific URL
		public void navigateTo() {
			driver.get("https://www.orangehrm.com/");
		}
		//Click on ContactSalesButton
		public void ContactSalesbutton() {
			WebElement click1=driver.findElement(By.xpath("//*[@id=\'navbarSupportedContent\']/div[2]/ul/li[2]/a/button"));
			click1.click();
		}
		// Set the full name field
		public void setFullName(String text) {
		    WebElement name =driver.findElement(By.name("FullName"));
			name.sendKeys(text);
		}
		// Set the phone number field
		public void setPhoneNumber(String text) {
			WebElement phone=driver.findElement(By.name("Contact"));
			phone.sendKeys(text);
		}
		// Set the email field
		public void setEmail(String text) {
			WebElement Email=driver.findElement(By.name("Email"));
			Email.sendKeys(text);
		}
		// Select a country from the dropdown
		public void Country(String country){
			Select country_name = new Select(driver.findElement(By.id("Form_getForm_Country")));
		    country_name.selectByVisibleText(country);	    
		}
		// Select the number of employees from the dropdown
		public void Employee(String employee) { 
			Select Employee_name = new Select(driver.findElement(By.id("Form_getForm_NoOfEmployees")));
		    Employee_name.selectByVisibleText(employee);			
		}
		// Set the job title field
		public void setJobTitle(String job) {
 		    WebElement jobtitle=driver.findElement(By.id("Form_getForm_JobTitle"));
		    jobtitle.sendKeys(job);
		}
		//Scrolling the page
		public void scrolling() {
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,350)");
		}
		//HandleCookies
		public void handleCookies() {
			WebElement cookies =driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[4]/div[2]/div"));
			cookies.click();
		}
		// Click the CAPTCHA (reCAPTCHA) element
		public void clickCaptcha(){		
			 WebElement frame=driver.findElement(By.xpath("//iframe[@title='reCAPTCHA']"));
			 driver.switchTo().frame(frame);
			 try {
			 JavascriptExecutor js=(JavascriptExecutor)driver;
			 WebElement checkbox=driver.findElement(By.xpath("//div[@class = 'recaptcha-checkbox-border']"));
		     js.executeScript("arguments[0].click();",checkbox);
			 driver.switchTo().defaultContent();
			 }
			 catch (Exception e) {
				 System.out.println(e.getMessage());
			 }     
		}
		//set the message
		public void setMessage(String message) {
			
			WebElement Message=driver.findElement(By.id("Form_getForm_Comment"));
			Message.sendKeys(message);		
			
		}

		//Click the "Submit" button 
		public void clickSubmit() {
			WebElement click=driver.findElement(By.id("Form_getForm_action_submitForm"));
			click.submit();
		}
		
		//Quit 
		public void tearDown() {
			driver.quit();
		}	
		
	}



