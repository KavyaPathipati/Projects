          
          Launch the browser. 
·         Enter the URL, “https://google.com” 
·         Enter the value in search or Edit box "Orange HRM demo”. 
·         Click on Search or press Enter. 
·         Search Result will be displayed. 
·         Click on Back arrow button and verify if the Google Page is appeared. 
·         Click on Forward arrow button and verify if it is redirected to the results page. 
·         Navigate to the page https://www.orangehrm.com/ 
·         Click CONTACT SALES and fill the all the fields as below. 
·         Your full Name: Vikram Rathode 
·         Phone Number: 1234567890 
·         JobTitle: Fresher 
·         Country: India 
·         No of Employees: 11-15 
·         Business Email: rathodeitsolutions.test@test.com 
·         Do not enter any message in the “your message” text box. 
·         Select Check box (I am not robot) and click submit button. 
·         Take Screenshot of the page. 
·         Enter any message in the “your message” text box. 
·         Select Check box (I am not robot) and click submit button.  
·         Close the browser. 

Key Automation Scope: 

·         Navigation to one step to another 
·         Handling Web elements 
·         Handling windows 
·         Working with mouse actions

Results :
Enter the browser name : Chrome or Edge
edge
Navigated back successfully
Navigated forward successfully


Jar files:
Selenium Java 4.17
Commons io 2.15.1
